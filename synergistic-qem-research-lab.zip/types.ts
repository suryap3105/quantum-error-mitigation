export type GateType = 'H' | 'X' | 'CNOT' | 'Z' | 'Y' | 'MEASURE' | 'RX' | 'RY' | 'RZ';

export interface Gate {
  id: string;
  type: GateType;
  targetQubit: number;
  controlQubit?: number;
  step: number;
}

export interface CircuitState {
  qubits: number;
  gates: Gate[];
}

export type StrategyType = 'BASELINE' | 'SUPPRESSION' | 'REJECTION' | 'SYNERGISTIC' | 'RL';

export type MoleculeType = 'H2' | 'LiH' | 'BeH2' | 'HeH+' | 'H4';

export type NoiseModelType = 'AMPLITUDE_DAMPING' | 'DEPOLARIZING' | 'PHASE_DAMPING' | 'COMBINED_REALISTIC';

export interface MoleculeDef {
  id: MoleculeType;
  name: string;
  formula: string;
  description: string;
  qubits: number;
  optimumR: number; // Equilibrium bond length
  defaultRange: number[]; // Points to simulate
}

export interface ExperimentPoint {
  r: number; // Bond length in Angstroms
  energy: number; // Measured Energy in Hartrees
  fci: number; // Full Configuration Interaction (Ideal) Energy
  discardRate: number; // 0.0 to 1.0
  error: number; // Absolute error from FCI
  stdErr: number; // Standard Error (Variance/sqrt(N))
  ciLow: number; // 95% Confidence Interval Lower Bound
  ciHigh: number; // 95% Confidence Interval Upper Bound
  rlAction?: string; // The strategy chosen by the RL agent for this point
}

export interface ExperimentResult {
  strategy: StrategyType;
  noiseLevel: number;
  noiseModel: NoiseModelType;
  shots: number; // Physical shot budget
  data: ExperimentPoint[];
  analysis: string;
}

export interface StrategyDef {
  id: StrategyType;
  name: string;
  description: string;
  color: string;
  type: 'No Mitigation' | 'Active (DD)' | 'Passive (Sym)' | 'Hybrid' | 'AI Agent';
}

export interface CalibrationData {
  t1: string;      // e.g. "54.2 µs"
  t2: string;      // e.g. "72.1 µs"
  gateFidelity: string; // e.g. "99.8%"
  readoutError: string; // e.g. "1.2%"
  status: 'ONLINE' | 'MAINTENANCE' | 'OFFLINE';
  lastCalibrated: string;
}

export interface ReferencePaper {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: string;
  category: string;
}