import { CircuitState, StrategyDef, ReferencePaper, MoleculeDef, NoiseModelType } from './types';

export const COLORS = {
  background: '#0f172a',
  surface: '#1e293b',
  grid: '#334155',
  text: '#cbd5e1',
  baseline: '#94a3b8', // Slate 400
  suppression: '#3b82f6', // Blue 500
  rejection: '#f97316', // Orange 500
  synergistic: '#10b981', // Emerald 500
  rl: '#a855f7', // Purple 500
  error: '#ef4444',
  success: '#22c55e',
  warning: '#eab308'
};

export const NOISE_MODELS: Record<NoiseModelType, { id: NoiseModelType, name: string, desc: string }> = {
    AMPLITUDE_DAMPING: { 
        id: 'AMPLITUDE_DAMPING', 
        name: 'Amplitude Damping (T1)', 
        desc: 'Energy relaxation. Dominant in superconducting qubits.' 
    },
    PHASE_DAMPING: { 
        id: 'PHASE_DAMPING', 
        name: 'Phase Damping (T2)', 
        desc: 'Loss of quantum information (coherence) without energy loss.' 
    },
    DEPOLARIZING: { 
        id: 'DEPOLARIZING', 
        name: 'Depolarizing (Global)', 
        desc: 'Symmetric white noise. Pushes state toward maximally mixed.' 
    },
    COMBINED_REALISTIC: {
        id: 'COMBINED_REALISTIC',
        name: 'Combined (Realistic Device)',
        desc: 'Superposition of T1, T2, and Gate Errors. Most accurate hardware model.'
    }
};

export const MOLECULES: Record<string, MoleculeDef> = {
  H2: {
    id: 'H2',
    name: 'Hydrogen',
    formula: 'H₂',
    description: 'STO-3G (4 Qubits)',
    qubits: 4,
    optimumR: 0.74,
    defaultRange: [0.5, 0.74, 1.0, 1.5, 2.0, 2.5]
  },
  'HeH+': {
      id: 'HeH+',
      name: 'Helium Hydride Ion',
      formula: 'HeH⁺',
      description: 'STO-3G (2 Qubits)',
      qubits: 2,
      optimumR: 0.77,
      defaultRange: [0.5, 0.77, 1.0, 1.5, 2.0, 2.5, 3.0]
  },
  LiH: {
    id: 'LiH',
    name: 'Lithium Hydride',
    formula: 'LiH',
    description: 'Active Space (6 Qubits)',
    qubits: 6,
    optimumR: 1.5,
    defaultRange: [1.0, 1.2, 1.5, 1.8, 2.2, 2.8]
  },
  BeH2: {
    id: 'BeH2',
    name: 'Beryllium Hydride',
    formula: 'BeH₂',
    description: 'Active Space (6 Qubits)',
    qubits: 6,
    optimumR: 1.3,
    defaultRange: [1.0, 1.3, 1.6, 2.0, 2.5, 3.0]
  },
  H4: {
      id: 'H4',
      name: 'Hydrogen Chain (H4)',
      formula: 'H₄',
      description: 'Linear Chain (8 Qubits)',
      qubits: 8,
      optimumR: 0.95,
      defaultRange: [0.7, 0.8, 0.9, 1.0, 1.2, 1.5, 2.0]
  }
};

export const STRATEGIES: Record<string, StrategyDef> = {
  BASELINE: {
    id: 'BASELINE',
    name: '0. Baseline',
    description: 'Standard noisy VQE execution. No mitigation applied.',
    color: COLORS.baseline,
    type: 'No Mitigation'
  },
  SUPPRESSION: {
    id: 'SUPPRESSION',
    name: 'A. Noise Suppression',
    description: 'Active Dynamical Decoupling (DD) sequences (XY4) applied to idle qubits.',
    color: COLORS.suppression,
    type: 'Active (DD)'
  },
  REJECTION: {
    id: 'REJECTION',
    name: 'B. Sym. Verification',
    description: 'Post-selection based on particle number conservation (N=const).',
    color: COLORS.rejection,
    type: 'Passive (Sym)'
  },
  SYNERGISTIC: {
    id: 'SYNERGISTIC',
    name: 'C. Hybrid (DD + Sym)',
    description: 'Hybrid: DD cleans distribution, reducing discard cost of Symmetry Verification.',
    color: COLORS.synergistic,
    type: 'Hybrid'
  },
  RL: {
    id: 'RL',
    name: 'D. RL Agent (PPO)',
    description: 'Stochastic agent selects optimal strategy per point. Includes exploration noise.',
    color: COLORS.rl,
    type: 'AI Agent'
  }
};

// --- ANSATZ DEFINITIONS ---

// 4-Qubit Hardware Efficient Ansatz for H2
export const H2_ANSATZ: CircuitState = {
  qubits: 4,
  gates: [
    // Initial State Prep (Hartree-Fock |1100>)
    { id: 'init1', type: 'X', targetQubit: 0, step: 0 },
    { id: 'init2', type: 'X', targetQubit: 1, step: 0 },
    
    // Entanglement Layer 1
    { id: 'ry1', type: 'RY', targetQubit: 0, step: 1 },
    { id: 'ry2', type: 'RY', targetQubit: 1, step: 1 },
    { id: 'ry3', type: 'RY', targetQubit: 2, step: 1 },
    { id: 'ry4', type: 'RY', targetQubit: 3, step: 1 },

    { id: 'cn1', type: 'CNOT', targetQubit: 1, controlQubit: 0, step: 2 },
    { id: 'cn2', type: 'CNOT', targetQubit: 2, controlQubit: 1, step: 3 },
    { id: 'cn3', type: 'CNOT', targetQubit: 3, controlQubit: 2, step: 4 },

    // Entanglement Layer 2
    { id: 'ry5', type: 'RY', targetQubit: 0, step: 5 },
    { id: 'ry6', type: 'RY', targetQubit: 1, step: 5 },
    { id: 'ry7', type: 'RY', targetQubit: 2, step: 5 },
    { id: 'ry8', type: 'RY', targetQubit: 3, step: 5 },

    { id: 'cn4', type: 'CNOT', targetQubit: 1, controlQubit: 0, step: 6 },
    { id: 'cn5', type: 'CNOT', targetQubit: 2, controlQubit: 1, step: 7 },
    { id: 'cn6', type: 'CNOT', targetQubit: 3, controlQubit: 2, step: 8 },

    // Measurement
    { id: 'm1', type: 'MEASURE', targetQubit: 0, step: 9 },
    { id: 'm2', type: 'MEASURE', targetQubit: 1, step: 9 },
    { id: 'm3', type: 'MEASURE', targetQubit: 2, step: 9 },
    { id: 'm4', type: 'MEASURE', targetQubit: 3, step: 9 },
  ]
};

// 2-Qubit Ansatz for HeH+ (Compact UCCSD-like)
const HEH_ANSATZ: CircuitState = {
    qubits: 2,
    gates: [
        { id: 'init1', type: 'X', targetQubit: 0, step: 0 },
        { id: 'ry1', type: 'RY', targetQubit: 0, step: 1 },
        { id: 'ry2', type: 'RY', targetQubit: 1, step: 1 },
        { id: 'cn1', type: 'CNOT', targetQubit: 1, controlQubit: 0, step: 2 },
        { id: 'rz1', type: 'RZ', targetQubit: 0, step: 3 },
        { id: 'rz2', type: 'RZ', targetQubit: 1, step: 3 },
        { id: 'ry3', type: 'RY', targetQubit: 0, step: 4 },
        { id: 'ry4', type: 'RY', targetQubit: 1, step: 4 },
        { id: 'm1', type: 'MEASURE', targetQubit: 0, step: 5 },
        { id: 'm2', type: 'MEASURE', targetQubit: 1, step: 5 },
    ]
};

// 6-Qubit HEA for LiH (Linear Connectivity)
const LIH_ANSATZ: CircuitState = {
    qubits: 6,
    gates: [
        // Init (HF: |111000>)
        { id: 'init0', type: 'X', targetQubit: 0, step: 0 },
        { id: 'init1', type: 'X', targetQubit: 1, step: 0 },
        { id: 'init2', type: 'X', targetQubit: 2, step: 0 },
        
        // Layer 1: Rotations
        { id: 'ry0', type: 'RY', targetQubit: 0, step: 1 },
        { id: 'ry1', type: 'RY', targetQubit: 1, step: 1 },
        { id: 'ry2', type: 'RY', targetQubit: 2, step: 1 },
        { id: 'ry3', type: 'RY', targetQubit: 3, step: 1 },
        { id: 'ry4', type: 'RY', targetQubit: 4, step: 1 },
        { id: 'ry5', type: 'RY', targetQubit: 5, step: 1 },

        // Layer 2: Nearest Neighbor Entanglement
        { id: 'cn0', type: 'CNOT', targetQubit: 1, controlQubit: 0, step: 2 },
        { id: 'cn1', type: 'CNOT', targetQubit: 2, controlQubit: 1, step: 3 },
        { id: 'cn2', type: 'CNOT', targetQubit: 3, controlQubit: 2, step: 4 },
        { id: 'cn3', type: 'CNOT', targetQubit: 4, controlQubit: 3, step: 5 },
        { id: 'cn4', type: 'CNOT', targetQubit: 5, controlQubit: 4, step: 6 },

        // Layer 3: Rotations
        { id: 'rz0', type: 'RZ', targetQubit: 0, step: 7 },
        { id: 'rz1', type: 'RZ', targetQubit: 1, step: 7 },
        { id: 'rz2', type: 'RZ', targetQubit: 2, step: 7 },
        { id: 'rz3', type: 'RZ', targetQubit: 3, step: 7 },
        { id: 'rz4', type: 'RZ', targetQubit: 4, step: 7 },
        { id: 'rz5', type: 'RZ', targetQubit: 5, step: 7 },

        // Measure
        { id: 'm0', type: 'MEASURE', targetQubit: 0, step: 8 },
        { id: 'm1', type: 'MEASURE', targetQubit: 1, step: 8 },
        { id: 'm2', type: 'MEASURE', targetQubit: 2, step: 8 },
        { id: 'm3', type: 'MEASURE', targetQubit: 3, step: 8 },
        { id: 'm4', type: 'MEASURE', targetQubit: 4, step: 8 },
        { id: 'm5', type: 'MEASURE', targetQubit: 5, step: 8 },
    ]
};

// 6-Qubit Ring HEA for BeH2 (Complex Entanglement)
const BEH2_ANSATZ: CircuitState = {
    qubits: 6,
    gates: [
        // Init (HF: |111000>)
        { id: 'init0', type: 'X', targetQubit: 0, step: 0 },
        { id: 'init1', type: 'X', targetQubit: 1, step: 0 },
        { id: 'init2', type: 'X', targetQubit: 2, step: 0 },

        // Superposition
        { id: 'h0', type: 'H', targetQubit: 0, step: 1 },
        { id: 'h1', type: 'H', targetQubit: 1, step: 1 },
        { id: 'h2', type: 'H', targetQubit: 2, step: 1 },
        { id: 'h3', type: 'H', targetQubit: 3, step: 1 },
        { id: 'h4', type: 'H', targetQubit: 4, step: 1 },
        { id: 'h5', type: 'H', targetQubit: 5, step: 1 },

        // Ring Entanglement
        { id: 'cn0', type: 'CNOT', targetQubit: 1, controlQubit: 0, step: 2 },
        { id: 'cn2', type: 'CNOT', targetQubit: 3, controlQubit: 2, step: 2 },
        { id: 'cn4', type: 'CNOT', targetQubit: 5, controlQubit: 4, step: 2 },
        
        { id: 'cn1', type: 'CNOT', targetQubit: 2, controlQubit: 1, step: 3 },
        { id: 'cn3', type: 'CNOT', targetQubit: 4, controlQubit: 3, step: 3 },
        { id: 'cn5', type: 'CNOT', targetQubit: 0, controlQubit: 5, step: 3 }, // Closing the ring

        // Rotations
        { id: 'ry0', type: 'RY', targetQubit: 0, step: 4 },
        { id: 'ry1', type: 'RY', targetQubit: 1, step: 4 },
        { id: 'ry2', type: 'RY', targetQubit: 2, step: 4 },
        { id: 'ry3', type: 'RY', targetQubit: 3, step: 4 },
        { id: 'ry4', type: 'RY', targetQubit: 4, step: 4 },
        { id: 'ry5', type: 'RY', targetQubit: 5, step: 4 },

        // Measure
        { id: 'm0', type: 'MEASURE', targetQubit: 0, step: 5 },
        { id: 'm1', type: 'MEASURE', targetQubit: 1, step: 5 },
        { id: 'm2', type: 'MEASURE', targetQubit: 2, step: 5 },
        { id: 'm3', type: 'MEASURE', targetQubit: 3, step: 5 },
        { id: 'm4', type: 'MEASURE', targetQubit: 4, step: 5 },
        { id: 'm5', type: 'MEASURE', targetQubit: 5, step: 5 },
    ]
};

// 8-Qubit Linear Ladder for H4 (High Depth)
const H4_ANSATZ: CircuitState = {
    qubits: 8,
    gates: [
        // Init HF: |11110000>
        { id: 'i0', type: 'X', targetQubit: 0, step: 0 },
        { id: 'i1', type: 'X', targetQubit: 1, step: 0 },
        { id: 'i2', type: 'X', targetQubit: 2, step: 0 },
        { id: 'i3', type: 'X', targetQubit: 3, step: 0 },

        // Rotations
        { id: 'r0', type: 'RY', targetQubit: 0, step: 1 },
        { id: 'r1', type: 'RY', targetQubit: 1, step: 1 },
        { id: 'r2', type: 'RY', targetQubit: 2, step: 1 },
        { id: 'r3', type: 'RY', targetQubit: 3, step: 1 },
        { id: 'r4', type: 'RY', targetQubit: 4, step: 1 },
        { id: 'r5', type: 'RY', targetQubit: 5, step: 1 },
        { id: 'r6', type: 'RY', targetQubit: 6, step: 1 },
        { id: 'r7', type: 'RY', targetQubit: 7, step: 1 },

        // Entanglement Ladder (Odd steps)
        { id: 'c0', type: 'CNOT', targetQubit: 1, controlQubit: 0, step: 2 },
        { id: 'c2', type: 'CNOT', targetQubit: 3, controlQubit: 2, step: 2 },
        { id: 'c4', type: 'CNOT', targetQubit: 5, controlQubit: 4, step: 2 },
        { id: 'c6', type: 'CNOT', targetQubit: 7, controlQubit: 6, step: 2 },

        // Entanglement Ladder (Even steps)
        { id: 'c1', type: 'CNOT', targetQubit: 2, controlQubit: 1, step: 3 },
        { id: 'c3', type: 'CNOT', targetQubit: 4, controlQubit: 3, step: 3 },
        { id: 'c5', type: 'CNOT', targetQubit: 6, controlQubit: 5, step: 3 },

        // Final Rotations
        { id: 'z0', type: 'RZ', targetQubit: 0, step: 4 },
        { id: 'z1', type: 'RZ', targetQubit: 1, step: 4 },
        { id: 'z2', type: 'RZ', targetQubit: 2, step: 4 },
        { id: 'z3', type: 'RZ', targetQubit: 3, step: 4 },
        { id: 'z4', type: 'RZ', targetQubit: 4, step: 4 },
        { id: 'z5', type: 'RZ', targetQubit: 5, step: 4 },
        { id: 'z6', type: 'RZ', targetQubit: 6, step: 4 },
        { id: 'z7', type: 'RZ', targetQubit: 7, step: 4 },

        // Measure
        { id: 'm0', type: 'MEASURE', targetQubit: 0, step: 5 },
        { id: 'm1', type: 'MEASURE', targetQubit: 1, step: 5 },
        { id: 'm2', type: 'MEASURE', targetQubit: 2, step: 5 },
        { id: 'm3', type: 'MEASURE', targetQubit: 3, step: 5 },
        { id: 'm4', type: 'MEASURE', targetQubit: 4, step: 5 },
        { id: 'm5', type: 'MEASURE', targetQubit: 5, step: 5 },
        { id: 'm6', type: 'MEASURE', targetQubit: 6, step: 5 },
        { id: 'm7', type: 'MEASURE', targetQubit: 7, step: 5 },
    ]
};

export const ANSATZ_CIRCUITS: Record<string, CircuitState> = {
    'H2': H2_ANSATZ,
    'HeH+': HEH_ANSATZ,
    'LiH': LIH_ANSATZ,
    'BeH2': BEH2_ANSATZ,
    'H4': H4_ANSATZ
};

export const LITERATURE: ReferencePaper[] = [
  {
    id: 'preskill2018',
    title: 'Quantum Computing in the NISQ era and beyond',
    authors: 'J. Preskill',
    journal: 'arXiv:1801.00862',
    year: '2018',
    category: 'NISQ Context'
  },
  {
    id: 'cai2023',
    title: 'Quantum error mitigation',
    authors: 'Z. Cai et al.',
    journal: 'Rev. Mod. Phys. 95',
    year: '2023',
    category: 'General QEM'
  },
  {
    id: 'bonet2018',
    title: 'Low-cost error mitigation by symmetry verification',
    authors: 'X. Bonet-Monroig et al.',
    journal: 'Phys. Rev. A 98',
    year: '2018',
    category: 'Symmetry Verification'
  },
  {
    id: 'das2021',
    title: 'Mitigating Idling Errors in Qubits via Adaptive Dynamical Decoupling',
    authors: 'P. Das et al.',
    journal: 'MICRO 2021',
    year: '2021',
    category: 'Dynamical Decoupling'
  },
  {
    id: 'lolur2023',
    title: 'Reference-State Error Mitigation for High Accuracy Quantum Chemistry',
    authors: 'P. Lolur et al.',
    journal: 'JCTC',
    year: '2023',
    category: 'Chemistry QEM'
  },
  {
      id: 'strikis2021',
      title: 'Learning-Based Quantum Error Mitigation',
      authors: 'A. Strikis et al.',
      journal: 'PRX Quantum',
      year: '2021',
      category: 'RL & QEM'
  }
];