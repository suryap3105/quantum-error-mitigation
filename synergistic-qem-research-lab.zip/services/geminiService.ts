import { GoogleGenAI, Type } from "@google/genai";
import { ExperimentResult, StrategyType, CalibrationData, MoleculeDef, NoiseModelType } from '../types';

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const runDiagnostics = async (): Promise<CalibrationData> => {
    // Simulate a device calibration run (T1/T2 measurement, RB for fidelity)
    const ai = getClient();
    const prompt = `
        Simulate a realistic calibration report for a superconducting Transmon quantum processor (e.g., IBM Eagle or Google Sycamore architecture).
        Return a JSON object with:
        - t1: coherence time around 50-100 microseconds (randomize slightly).
        - t2: coherence time around 70-120 microseconds (randomize slightly).
        - gateFidelity: 2-qubit gate fidelity (around 99.5% - 99.9%).
        - readoutError: Measurement error (around 1% - 3%).
        - status: "ONLINE".
        - lastCalibrated: Current timestamp.
        
        Format values as strings with units (e.g., "75.2 µs").
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        t1: { type: Type.STRING },
                        t2: { type: Type.STRING },
                        gateFidelity: { type: Type.STRING },
                        readoutError: { type: Type.STRING },
                        status: { type: Type.STRING },
                        lastCalibrated: { type: Type.STRING }
                    }
                }
            }
        });
        
        if (!response.text) throw new Error("Diagnostic failed");
        return JSON.parse(response.text);
    } catch (e) {
        // Fallback for offline resilience
        return {
            t1: "Unknown",
            t2: "Unknown",
            gateFidelity: "Unknown",
            readoutError: "Unknown",
            status: "OFFLINE",
            lastCalibrated: new Date().toISOString()
        };
    }
};

export const runVQEExperiment = async (
  strategy: StrategyType,
  noiseLevel: number,
  noiseModel: NoiseModelType,
  shots: number,
  molecule: MoleculeDef
): Promise<ExperimentResult> => {
  const ai = getClient();

  // Determine Noise Regime for Prompt Context
  let regime = "LOW";
  if (noiseLevel > 0.04) regime = "MEDIUM";
  if (noiseLevel > 0.10) regime = "HIGH";

  // Calculate the theoretical sampling floor for this shot count to guide the AI
  const baseSamplingFloor = 1.0 / Math.sqrt(shots);
  const floorMHa = (baseSamplingFloor * 1000).toFixed(1);

  const isRL = strategy === 'RL';
  const pointsToSimulate = molecule.defaultRange.join(', ');

  const prompt = `
    Act as a high-fidelity Quantum Density Matrix Simulator for ${molecule.name} VQE (${molecule.qubits} Qubits).
    Target: Dissociation Curve (R: [${pointsToSimulate}] Å).
    Input Gamma (Noise): ${noiseLevel} (Regime: ${regime}).
    Noise Model: ${noiseModel}.
    Shots: ${shots} (Fixed Physical Budget).
    Strategy: ${strategy} ${isRL ? '(Stochastic PPO Agent)' : ''}

    *** PHYSICS SIMULATION CONSTRAINTS ***
    
    1. **SAMPLING NOISE FLOOR**: 
       - With ${shots} shots, the statistical floor is approx ${floorMHa} mHa.
       - NO STRATEGY (even Hybrid) should consistently be below this floor.

    2. **DISCARD RATES (Probability of Rejection)**:
       - **BASELINE / SUPPRESSION**: 0.0
       - **REJECTION (Sym)**: Low Noise: 0.4-0.5, High Noise: 0.85-0.95.
       - **HYBRID (Synergistic)**: Low Noise: 0.10-0.15, High Noise: 0.25-0.35.
       - **RL AGENT**: 
          - MUST VARY per point.
          - If Action="Baseline", Discard=0. 
          - If Action="Sym", Discard > 0.8. 
          - If Action="Hybrid", Discard ~0.25.

    3. **NOISE MODEL CHARACTERISTICS (CRITICAL)**:
       - **AMPLITUDE_DAMPING** (T1): Energy relaxation. The curve often dips *below* FCI (non-variational) at large R or drifts significantly. High bias.
       - **PHASE_DAMPING** (T2): Pure dephasing. Energy tends to be closer to correct but variance is higher. Does not lower energy below ground, usually raises it.
       - **DEPOLARIZING**: Global white noise. Squashes the curve towards 0 (or Identity trace). Raises energy significantly everywhere.
       - **COMBINED_REALISTIC**: 
          - **Superposition of ALL errors** (T1 + T2 + Gate/Readout + Coherent Errors).
          - This represents a real, messy device (e.g., crosstalk).
          - The curve should NOT be smooth; it should have slight "bumps" or asymmetries.
          - Expect HIGHER bias than any single model.
          - Expect HIGHER discard rates (e.g., Sym discard > 95% in High noise).
          - Even Hybrid strategy should struggle to reach Chemical Accuracy here.

    4. **RL AGENT BEHAVIOR**:
       - The RL agent is stochastic and trained via PPO.
       - It does NOT magically beat Hybrid everywhere. 
       - At very low R, it might pick Baseline (low cost).
       - At high R, it usually picks Hybrid.
       - Sometimes it picks suboptimal actions due to exploration.
       - Its energy curve should be "bumpy".

    Return JSON for R=[${pointsToSimulate}].
    - 'energy': Measured Energy (FCI + Bias + Noise).
    - 'fci': The ideal value.
    - 'discardRate': 0.0 to 1.0.
    ${isRL ? "- 'rlAction': Chosen action name (e.g. 'Hybrid', 'Baseline', 'Sym')." : ""}
    - 'analysis': MAX 10 WORDS. Very brief observation.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          data: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                r: { type: Type.NUMBER },
                energy: { type: Type.NUMBER, description: "Measured Energy (Hartrees)" },
                fci: { type: Type.NUMBER },
                discardRate: { type: Type.NUMBER },
                rlAction: { type: Type.STRING, description: "Only if strategy is RL" },
              }
            }
          },
          analysis: { type: Type.STRING }
        }
      }
    }
  });

  if (!response.text) {
    throw new Error("No response from AI simulator");
  }

  let cleanText = response.text.trim();
  if (cleanText.startsWith('```json')) {
      cleanText = cleanText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleanText.startsWith('```')) {
      cleanText = cleanText.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }

  try {
      const result = JSON.parse(cleanText);
      
      const processedData = (result.data || []).map((p: any) => {
          const error = Math.abs(p.energy - p.fci);
          const fractionKept = Math.max(0.001, 1.0 - p.discardRate);
          const validShots = shots * fractionKept;
          const stdErr = 1.0 / Math.sqrt(validShots);
          
          return {
              ...p,
              error: error,
              stdErr: stdErr,
              ciLow: p.energy - (1.96 * stdErr),
              ciHigh: p.energy + (1.96 * stdErr),
              rlAction: p.rlAction || undefined
          };
      });

      return {
        strategy,
        noiseLevel,
        noiseModel,
        shots,
        data: processedData,
        analysis: result.analysis || "Simulation complete."
      };
  } catch (e) {
      console.error("JSON Parsing failed. Response snippet:", cleanText.substring(0, 100));
      return {
          strategy,
          noiseLevel,
          noiseModel,
          shots,
          data: [],
          analysis: "Error: Simulation data malformed."
      };
  }
};

export const explainConcept = async (concept: string): Promise<string> => {
  const ai = getClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Explain the concept "${concept}" in the context of NISQ Quantum Error Mitigation. 
    Refer to seminal papers if applicable (e.g., Preskill 2018, Cai 2023). 
    Keep it technical but concise (under 50 words).`
  });
  return response.text || "No explanation available.";
};