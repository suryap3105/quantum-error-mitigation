import React from 'react';
import { CircuitState, Gate, GateType } from '../types';
import { X, Plus, Minus, GitCommit, Search } from 'lucide-react';

interface CircuitDiagramProps {
  circuit: CircuitState;
  onAddGate: (qubit: number, step: number) => void;
  onRemoveGate: (id: string) => void;
  readOnly?: boolean;
}

const GATE_SIZE = 40;
const STEP_WIDTH = 60;
const LINE_HEIGHT = 60;

const GateIcon: React.FC<{ type: GateType }> = ({ type }) => {
  switch (type) {
    case 'H': return <span className="font-bold text-sm">H</span>;
    case 'X': return <span className="font-bold text-sm">X</span>;
    case 'Z': return <span className="font-bold text-sm">Z</span>;
    case 'CNOT': return <div className="w-2 h-2 rounded-full bg-white"></div>;
    case 'MEASURE': return <Search size={14} />;
    default: return <span>{type}</span>;
  }
};

const CircuitDiagram: React.FC<CircuitDiagramProps> = ({ circuit, onAddGate, onRemoveGate, readOnly = false }) => {
  const maxSteps = Math.max(5, ...circuit.gates.map(g => g.step + 1));

  return (
    <div className="overflow-x-auto p-6 bg-slate-900 rounded-xl border border-slate-800 shadow-inner">
      <div 
        className="relative"
        style={{ 
          height: circuit.qubits * LINE_HEIGHT, 
          width: (maxSteps + 1) * STEP_WIDTH 
        }}
      >
        {/* Render Quantum Wires */}
        {Array.from({ length: circuit.qubits }).map((_, i) => (
          <div 
            key={`wire-${i}`}
            className="absolute w-full border-t border-slate-600 flex items-center"
            style={{ top: i * LINE_HEIGHT + LINE_HEIGHT / 2, left: 0 }}
          >
            <span className="absolute -left-8 text-slate-400 font-mono text-sm">q{i}</span>
          </div>
        ))}

        {/* Render Gates */}
        {circuit.gates.map((gate) => {
          const top = gate.targetQubit * LINE_HEIGHT + (LINE_HEIGHT - GATE_SIZE) / 2;
          const left = gate.step * STEP_WIDTH + 20;

          // CNOT Vertical Line Logic
          let connectorHeight = 0;
          let connectorTop = 0;
          let showConnector = false;

          if (gate.type === 'CNOT' && gate.controlQubit !== undefined) {
            showConnector = true;
            const controlTop = gate.controlQubit * LINE_HEIGHT + LINE_HEIGHT / 2;
            const targetCenter = top + GATE_SIZE / 2;
            connectorHeight = Math.abs(targetCenter - controlTop);
            connectorTop = Math.min(controlTop, targetCenter);
          }

          return (
            <React.Fragment key={gate.id}>
              {/* Connector Line for CNOT */}
              {showConnector && (
                <div 
                  className="absolute w-0.5 bg-cyan-500 z-10"
                  style={{
                    height: connectorHeight,
                    top: connectorTop,
                    left: left + GATE_SIZE / 2,
                  }}
                />
              )}
              
              {/* Control Dot for CNOT */}
              {gate.type === 'CNOT' && gate.controlQubit !== undefined && (
                 <div 
                 className="absolute w-3 h-3 bg-cyan-500 rounded-full z-20"
                 style={{
                   top: gate.controlQubit * LINE_HEIGHT + LINE_HEIGHT / 2 - 6,
                   left: left + GATE_SIZE / 2 - 6,
                 }}
               />
              )}

              {/* The Gate Itself */}
              <div
                className={`absolute z-20 flex items-center justify-center rounded shadow-md cursor-pointer transition-transform hover:scale-110 
                  ${gate.type === 'MEASURE' ? 'bg-slate-700 border-slate-500 text-slate-300' : 'bg-cyan-600 border-cyan-400 text-white'}
                  ${gate.type === 'CNOT' ? 'rounded-full border-2' : 'border'}`}
                style={{
                  width: GATE_SIZE,
                  height: GATE_SIZE,
                  top,
                  left
                }}
                onClick={() => !readOnly && onRemoveGate(gate.id)}
                title={readOnly ? "" : "Click to remove"}
              >
                <GateIcon type={gate.type} />
              </div>
            </React.Fragment>
          );
        })}

        {/* Interaction Zones (Ghost placeholders to add gates) */}
        {!readOnly && Array.from({ length: circuit.qubits }).map((_, qIdx) => 
          Array.from({ length: maxSteps }).map((_, sIdx) => {
             const hasGate = circuit.gates.some(g => g.targetQubit === qIdx && g.step === sIdx);
             if (hasGate) return null;

             return (
               <div
                 key={`ghost-${qIdx}-${sIdx}`}
                 className="absolute hover:bg-white/10 rounded-full cursor-pointer transition-colors"
                 style={{
                   width: GATE_SIZE,
                   height: GATE_SIZE,
                   top: qIdx * LINE_HEIGHT + (LINE_HEIGHT - GATE_SIZE) / 2,
                   left: sIdx * STEP_WIDTH + 20
                 }}
                 onClick={() => onAddGate(qIdx, sIdx)}
               />
             );
          })
        )}
      </div>
    </div>
  );
};

export default CircuitDiagram;
