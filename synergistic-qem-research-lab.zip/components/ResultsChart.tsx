import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ReferenceArea, Area } from 'recharts';
import { ExperimentResult, StrategyType } from '../types';
import { COLORS, STRATEGIES } from '../constants';
import { MousePointer2, BarChart3, BrainCircuit } from 'lucide-react';

interface ResultsChartProps {
  results: Record<string, ExperimentResult>;
  activeStrategies: StrategyType[];
  loading: boolean;
  activeMoleculeName: string;
  activeNoiseModelName: string;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl text-xs z-50">
        <p className="font-bold text-slate-300 mb-2">Bond Length: {label} Å</p>
        
        {/* Render FCI First */}
        {payload.find((p: any) => p.name === "FCI (Exact)") && (
             <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-800">
                <span className="w-2 h-2 rounded-full bg-pink-400" />
                <span className="text-pink-400 font-mono">FCI: {payload.find((p: any) => p.name === "FCI (Exact)").value.toFixed(4)} Ha</span>
             </div>
        )}

        {payload.filter((p: any) => p.name !== "FCI (Exact)" && !p.name.includes('CI')).map((entry: any) => {
           // Find the StdErr from the original data object if possible
           const stdErr = entry.payload[`${entry.name}_stdErr`];
           const rlAction = entry.payload[`${entry.name}_rlAction`];
           
           return (
            <div key={entry.name} className="flex flex-col mb-2">
                <div className="flex items-center gap-2" style={{ color: entry.color }}>
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                    <span className="font-semibold">{entry.name}</span>
                </div>
                <div className="pl-4 font-mono text-slate-400">
                    E: <span className="text-slate-200">{entry.value.toFixed(4)}</span> 
                    {stdErr !== undefined && <span className="text-slate-500 mx-1">± {stdErr.toFixed(4)}</span>}
                </div>
                {rlAction && (
                    <div className="pl-4 mt-0.5 text-[10px] text-purple-400">
                        Agent Selected: <span className="font-bold">{rlAction}</span>
                    </div>
                )}
            </div>
           );
        })}
      </div>
    );
  }
  return null;
};

const ScatterTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length && payload[0] && payload[0].payload) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl text-xs z-50">
          <p className="font-bold text-slate-200 mb-1">{data.name}</p>
          <p className="text-slate-400">Avg Error: <span className="text-white font-mono">{data.x?.toFixed(2)} mHa</span></p>
          <p className="text-slate-400">Discard Rate: <span className="text-white font-mono">{(data.y * 100).toFixed(1)}%</span></p>
        </div>
      );
    }
    return null;
};

const ResultsChart: React.FC<ResultsChartProps> = ({ 
    results, 
    activeStrategies, 
    loading, 
    activeMoleculeName, 
    activeNoiseModelName 
}) => {
  const [viewMode, setViewMode] = useState<'CURVE' | 'SCATTER'>('CURVE');

  // --- Data Prep for Dissociation Curve ---
  const validResultKey = Object.keys(results).find(key => results[key] && results[key].data && results[key].data.length > 0);
  const firstValidResult = validResultKey ? results[validResultKey] : null;

  const curveData = firstValidResult ? firstValidResult.data.map((point, index) => {
    const combinedPoint: any = { r: point.r, FCI: point.fci };
    activeStrategies.forEach(strat => {
      // Defensive check if strategy result exists
      if (results[strat] && results[strat].data && results[strat].data[index]) {
        // Defensive check if STRATEGIES[strat] exists
        if (STRATEGIES[strat]) {
            const stratName = STRATEGIES[strat].name;
            const dataPoint = results[strat].data[index];
            combinedPoint[stratName] = dataPoint.energy;
            // Flatten StdErr, CI, and RL Action for Tooltip/Area access
            combinedPoint[`${stratName}_stdErr`] = dataPoint.stdErr;
            // Recharts Area Range format: [min, max]
            combinedPoint[`${stratName}_ci`] = [dataPoint.ciLow, dataPoint.ciHigh];
            combinedPoint[`${stratName}_rlAction`] = dataPoint.rlAction;
        }
      }
    });
    return combinedPoint;
  }) : [];

  // --- Data Prep for Synergy Scatter (Error vs Discard) ---
  const scatterData = activeStrategies.map(strat => {
    if (!results[strat] || !results[strat].data || results[strat].data.length === 0 || !STRATEGIES[strat]) return null;
    const dataPoints = results[strat].data;
    const avgError = dataPoints.reduce((acc, p) => acc + (Math.abs(p.error) * 1000), 0) / dataPoints.length; // mHa
    const avgDiscard = dataPoints.reduce((acc, p) => acc + p.discardRate, 0) / dataPoints.length; // 0-1
    return {
      name: STRATEGIES[strat].name,
      x: avgError, 
      y: avgDiscard,
      fill: STRATEGIES[strat].color,
      shape: strat === 'SYNERGISTIC' ? 'star' : (strat === 'RL' ? 'diamond' : 'circle')
    };
  }).filter(Boolean);

  if (loading && curveData.length === 0) {
    return (
      <div className="h-96 flex flex-col items-center justify-center bg-slate-900/50 rounded-xl border border-slate-800 animate-pulse">
        <div className="text-cyan-500 font-mono text-lg">Running Rust Backend Simulation...</div>
        <div className="text-slate-500 text-sm mt-2">Computing Density Matrices & Kraus Operators</div>
      </div>
    );
  }

  if (curveData.length === 0) {
    return (
      <div className="h-96 flex items-center justify-center bg-slate-900/50 rounded-xl border border-slate-800 text-slate-500">
        Run experiment to visualize Synergistic Quantum Error Mitigation.
      </div>
    );
  }

  return (
    <div className="space-y-6">
        {/* Tab Controls & Header Context */}
        <div className="flex justify-between items-center">
             <div className="text-xs font-mono text-slate-500 hidden md:block">
                Context: <span className="text-slate-300">{activeMoleculeName}</span> | <span className="text-slate-300">{activeNoiseModelName}</span>
             </div>
             <div className="flex gap-2">
                <button 
                    onClick={() => setViewMode('CURVE')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-2 transition-colors ${viewMode === 'CURVE' ? 'bg-slate-700 text-white' : 'bg-slate-900 text-slate-500 hover:text-slate-300'}`}
                >
                    <BarChart3 size={14} /> Dissociation Curve
                </button>
                <button 
                    onClick={() => setViewMode('SCATTER')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-2 transition-colors ${viewMode === 'SCATTER' ? 'bg-slate-700 text-white' : 'bg-slate-900 text-slate-500 hover:text-slate-300'}`}
                >
                    <MousePointer2 size={14} /> Synergy Landscape
                </button>
             </div>
        </div>

      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg relative min-h-[400px]">
        {viewMode === 'CURVE' ? (
             <>
             <div className="flex justify-between items-end mb-4">
                 <div>
                     <h3 className="text-lg font-semibold text-slate-200 flex items-center gap-2">
                        Dissociation Curve
                        <span className="text-sm font-normal text-slate-500 border-l border-slate-700 pl-2 ml-2 hidden sm:inline">
                            {activeMoleculeName}
                        </span>
                     </h3>
                     <p className="text-xs text-slate-400">Fixed Shot Budget (N=10,000) | Shaded Areas = 95% Confidence Interval</p>
                 </div>
                 <div className="flex flex-col items-end gap-1">
                     <div className="text-xs font-mono text-emerald-500 bg-emerald-950/30 px-2 py-1 rounded border border-emerald-900">
                        Chemical Accuracy Limit (1.6 mHa)
                     </div>
                 </div>
             </div>
             
             <div style={{ width: '100%', height: '320px' }}>
               <ResponsiveContainer width="100%" height="100%">
                 <LineChart data={curveData} margin={{ top: 5, right: 30, left: 20, bottom: 20 }}>
                   <CartesianGrid strokeDasharray="3 3" stroke={COLORS.grid} opacity={0.3} />
                   <XAxis 
                     dataKey="r" 
                     stroke={COLORS.text} 
                     label={{ value: 'Bond Length (Å)', position: 'insideBottom', offset: -10, fill: COLORS.text, fontSize: 12 }} 
                   />
                   <YAxis 
                     stroke={COLORS.text} 
                     domain={['auto', 'auto']}
                     label={{ value: 'Energy (Ha)', angle: -90, position: 'insideLeft', fill: COLORS.text, fontSize: 12 }}
                   />
                   <Tooltip content={<CustomTooltip />} />
                   <Legend wrapperStyle={{ paddingTop: '10px' }} />
                   
                   <Line type="monotone" dataKey="FCI" stroke="#f472b6" strokeWidth={2} strokeDasharray="5 5" dot={false} name="FCI (Exact)" />
                   
                   {activeStrategies.map(strat => {
                     if (!results[strat] || !results[strat].data || results[strat].data.length === 0 || !STRATEGIES[strat]) return null;

                     const stratName = STRATEGIES[strat].name;
                     return (
                       <React.Fragment key={strat}>
                           {/* Confidence Interval Band */}
                           <Area 
                                type="monotone"
                                dataKey={`${stratName}_ci`} 
                                stroke="none" 
                                fill={STRATEGIES[strat].color} 
                                fillOpacity={0.15} 
                                name={`${stratName} (95% CI)`}
                                legendType="none"
                           />
                           {/* Main Line */}
                           <Line
                             type="monotone"
                             dataKey={stratName}
                             stroke={STRATEGIES[strat].color}
                             strokeWidth={2.5}
                             dot={{ r: 3 }}
                             activeDot={{ r: 5 }}
                           />
                       </React.Fragment>
                     );
                   })}
                 </LineChart>
               </ResponsiveContainer>
             </div>
             
             {/* RL Policy Map */}
             {activeStrategies.includes('RL') && results['RL'] && (
                 <div className="mt-4 pt-4 border-t border-slate-800">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                         <BrainCircuit size={12} className="text-purple-400"/> RL Agent Policy Map
                    </h4>
                    <div className="flex justify-between items-center text-[10px] bg-slate-950/50 rounded p-2 overflow-x-auto">
                        {results['RL'].data.map((pt, idx) => (
                            <div key={idx} className="flex flex-col items-center min-w-[50px]">
                                <span className="text-slate-500 mb-1">{pt.r}Å</span>
                                <div 
                                    className="px-2 py-0.5 rounded text-white font-mono border"
                                    style={{
                                        backgroundColor: pt.rlAction === 'Baseline' ? COLORS.baseline :
                                                        pt.rlAction === 'Sym' ? COLORS.rejection : 
                                                        pt.rlAction === 'Hybrid' ? COLORS.synergistic : COLORS.rl,
                                        borderColor: 'rgba(255,255,255,0.1)'
                                    }}
                                >
                                    {pt.rlAction || 'RL'}
                                </div>
                            </div>
                        ))}
                    </div>
                 </div>
             )}
           </>
        ) : (
            <>
            <div className="flex justify-between items-end mb-4">
                <div>
                    <h3 className="text-lg font-semibold text-slate-200">The Synergy Landscape</h3>
                    <p className="text-xs text-slate-400">Average Error vs. Data Discard Rate</p>
                </div>
                <div className="text-xs text-slate-500 max-w-xs text-right hidden sm:block">
                   Goal: Bottom-Left Corner (Low Error, Low Data Loss).
                </div>
            </div>
            
            <div style={{ width: '100%', height: '320px' }} className="bg-slate-900/50 rounded border border-slate-800/50 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.grid} opacity={0.2} />
                  <XAxis 
                    type="number" 
                    dataKey="x" 
                    name="Error" 
                    unit=" mHa" 
                    stroke={COLORS.text}
                    label={{ value: 'Average Error (mHa)', position: 'insideBottom', offset: -10, fill: COLORS.text, fontSize: 12 }}
                  />
                  <YAxis 
                    type="number" 
                    dataKey="y" 
                    name="Discard Rate" 
                    unit="" 
                    stroke={COLORS.text}
                    tickFormatter={(val) => `${(val * 100).toFixed(0)}%`}
                    label={{ value: 'Discard Rate (%)', angle: -90, position: 'insideLeft', fill: COLORS.text, fontSize: 12 }}
                  />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} content={<ScatterTooltip />} />
                  <Legend />
                  
                  <ReferenceArea x1={0} x2={20} y1={0} y2={0.25} stroke="none" fill="rgba(16, 185, 129, 0.1)" />
                  
                  {scatterData.map((entry: any, index) => (
                      <Scatter 
                        key={index} 
                        name={entry.name} 
                        data={[entry]} 
                        fill={entry.fill} 
                        shape={entry.shape === 'star' ? "star" : "circle"}
                      />
                  ))}
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </>
        )}
      </div>
      
      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
         {activeStrategies.map(strat => {
            if (!results[strat] || !results[strat].data || results[strat].data.length === 0 || !STRATEGIES[strat]) return null;
            const avgError = results[strat].data.reduce((acc, p) => acc + Math.abs(p.error), 0) / results[strat].data.length;
            const avgDiscard = results[strat].data.reduce((acc, p) => acc + p.discardRate, 0) / results[strat].data.length;
            
            return (
                <div key={`${strat}-metrics`} className="bg-slate-900/80 p-3 rounded-lg border-b-2" style={{ borderColor: STRATEGIES[strat].color }}>
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-[10px] uppercase font-bold text-slate-500">{STRATEGIES[strat].type}</span>
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: STRATEGIES[strat].color }} />
                    </div>
                    <div className="flex justify-between items-end">
                       <div>
                            <div className="text-[10px] text-slate-400">Error (mHa)</div>
                            <div className="text-sm font-mono text-slate-200">{(avgError * 1000).toFixed(1)}</div>
                       </div>
                       <div className="text-right">
                            <div className="text-[10px] text-slate-400">Discard</div>
                            <div className={`text-sm font-mono ${avgDiscard > 0.4 ? 'text-red-400' : 'text-slate-200'}`}>
                                {(avgDiscard * 100).toFixed(0)}%
                            </div>
                       </div>
                    </div>
                </div>
            );
         })}
      </div>
    </div>
  );
};

export default ResultsChart;