import React, { useState, useEffect } from 'react';
import { Activity, Play, Layers, GitMerge, ShieldCheck, Zap, Github, Settings, AlertTriangle, XCircle, BookOpen, AlertCircle, RefreshCw, Cpu, Database, BrainCircuit, Atom, Waves, Download } from 'lucide-react';
import CircuitDiagram from './components/CircuitDiagram';
import ResultsChart from './components/ResultsChart';
import { ExperimentResult, StrategyType, CalibrationData, MoleculeType, NoiseModelType } from './types';
import { STRATEGIES, H2_ANSATZ, LITERATURE, MOLECULES, NOISE_MODELS, ANSATZ_CIRCUITS } from './constants';
import { runVQEExperiment, explainConcept, runDiagnostics } from './services/geminiService';

const App: React.FC = () => {
  const [activeStrategies, setActiveStrategies] = useState<StrategyType[]>(['BASELINE', 'SYNERGISTIC', 'RL']);
  const [results, setResults] = useState<Record<string, ExperimentResult>>({});
  
  // Physics Parameters
  const [activeMoleculeId, setActiveMoleculeId] = useState<MoleculeType>('H2');
  const [noiseLevel, setNoiseLevel] = useState<number>(0.08);
  const [noiseModel, setNoiseModel] = useState<NoiseModelType>('AMPLITUDE_DAMPING');
  const [shots, setShots] = useState<number>(10000);
  
  const [loading, setLoading] = useState(false);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [calibration, setCalibration] = useState<CalibrationData | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [showReferences, setShowReferences] = useState(false);

  // Initial System Check
  useEffect(() => {
    handleRunDiagnostics();
  }, []);

  const handleRunDiagnostics = async () => {
    try {
        const cal = await runDiagnostics();
        setCalibration(cal);
    } catch (e) {
        console.error("Diagnostic check failed", e);
        setCalibration({
            t1: "N/A", t2: "N/A", gateFidelity: "N/A", readoutError: "N/A", 
            status: "OFFLINE", lastCalibrated: new Date().toISOString()
        });
    }
  };

  const toggleStrategy = (id: StrategyType) => {
    setActiveStrategies(prev => 
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const handleRunExperiment = async () => {
    if (!calibration || calibration.status === 'OFFLINE') {
        setErrorMsg("Device is offline. Run Diagnostics to recalibrate.");
        return;
    }
    setLoading(true);
    setExplanation(null);
    setErrorMsg(null);
    
    try {
      // Parallel execution simulation
      const currentMolecule = MOLECULES[activeMoleculeId] || MOLECULES['H2'];
      const promises = activeStrategies.map(strat => runVQEExperiment(strat, noiseLevel, noiseModel, shots, currentMolecule));
      const newResultsArray = await Promise.all(promises);
      
      const newResultsMap = { ...results };
      newResultsArray.forEach(res => {
        newResultsMap[res.strategy] = res;
      });
      
      setResults(newResultsMap);
    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.message || "Simulation failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleExportData = () => {
    if (Object.keys(results).length === 0) return;
    const exportData = {
        meta: {
            molecule: activeMoleculeId,
            shots,
            noiseLevel,
            noiseModel,
            timestamp: new Date().toISOString(),
            calibration
        },
        results
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qem_lab_${activeMoleculeId}_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const loadConcept = async (concept: string) => {
    setExplanation("Consulting Knowledge Base...");
    try {
        const text = await explainConcept(concept);
        setExplanation(text);
    } catch (e) {
        setExplanation("Could not retrieve explanation.");
    }
  };

  const getIconForStrategy = (type: string) => {
    switch (type) {
      case 'Active (DD)': return <Zap size={16} />;
      case 'Passive (Sym)': return <ShieldCheck size={16} />;
      case 'Hybrid': return <GitMerge size={16} />;
      case 'AI Agent': return <BrainCircuit size={16} />;
      default: return <Activity size={16} />;
    }
  };

  const activeMolecule = MOLECULES[activeMoleculeId] || MOLECULES['H2'];
  const activeCircuit = ANSATZ_CIRCUITS[activeMoleculeId] || ANSATZ_CIRCUITS['H2'];

  return (
    <div className="min-h-screen bg-[#0b1120] text-slate-100 font-sans selection:bg-indigo-500/30 flex flex-col">
      
      {/* Error Banner */}
      {errorMsg && (
          <div className="bg-red-900/50 border-b border-red-800 text-red-200 px-6 py-2 flex justify-between items-center text-xs">
              <span className="flex items-center gap-2"><AlertTriangle size={14} /> {errorMsg}</span>
              <button onClick={() => setErrorMsg(null)}><XCircle size={14} /></button>
          </div>
      )}

      {/* Lab Header */}
      <header className="border-b border-slate-800 bg-[#0f172a] sticky top-0 z-50 shadow-md">
        <div className="w-full px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-900/20">
                <Layers className="text-white" size={20} />
             </div>
             <div>
               <h1 className="text-base font-bold text-slate-100 tracking-tight leading-none">QEM Research Lab</h1>
               <div className="flex items-center gap-2 text-[10px] text-indigo-300 font-mono mt-0.5">
                 <span>v2.3.0-Hybrid</span>
                 <span className="text-slate-600">|</span>
                 <span>NISQ Simulator</span>
               </div>
             </div>
          </div>
          
          <div className="flex items-center gap-3">
             {calibration && (
                 <button 
                   onClick={() => setShowDiagnostics(!showDiagnostics)}
                   className={`hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono border transition-colors
                   ${calibration.status === 'ONLINE' ? 'bg-emerald-900/20 border-emerald-900/50 text-emerald-400 hover:bg-emerald-900/30' : 'bg-red-900/20 border-red-900 text-red-400'}`}
                 >
                    <div className={`w-1.5 h-1.5 rounded-full ${calibration.status === 'ONLINE' ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
                    {calibration.status === 'ONLINE' ? 'BACKEND ONLINE' : 'BACKEND OFFLINE'}
                 </button>
             )}
             
             <div className="h-6 w-px bg-slate-800 mx-2" />

             <button 
                onClick={() => setShowReferences(!showReferences)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-md border border-slate-700 transition-colors"
             >
                <BookOpen size={14} />
                <span className="hidden sm:inline">Literature</span>
             </button>

             <a href="https://github.com/suryap3105/quantum-error-mitigation" target="_blank" rel="noreferrer" className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-md text-xs font-medium text-slate-300 transition-colors border border-slate-700">
               <Github size={14} />
             </a>
          </div>
        </div>
        
        {/* Diagnostics Dropdown */}
        {showDiagnostics && calibration && (
            <div className="absolute top-full right-6 z-50 w-72 bg-slate-900 border border-slate-700 rounded-b-xl shadow-2xl p-4 animate-in slide-in-from-top-2">
                <div className="flex justify-between items-center mb-3">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Device Calibration</h3>
                    <button onClick={handleRunDiagnostics} className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
                        <RefreshCw size={12} /> Recalibrate
                    </button>
                </div>
                <div className="space-y-2">
                    <div className="flex justify-between text-xs border-b border-slate-800 pb-1">
                        <span className="text-slate-500">T1 Relaxation</span>
                        <span className="font-mono text-emerald-400">{calibration.t1}</span>
                    </div>
                    <div className="flex justify-between text-xs border-b border-slate-800 pb-1">
                        <span className="text-slate-500">T2 Dephasing</span>
                        <span className="font-mono text-emerald-400">{calibration.t2}</span>
                    </div>
                    <div className="flex justify-between text-xs border-b border-slate-800 pb-1">
                        <span className="text-slate-500">Gate Fidelity (2Q)</span>
                        <span className="font-mono text-blue-400">{calibration.gateFidelity}</span>
                    </div>
                    <div className="text-[10px] text-slate-600 mt-2 text-right">
                        Last Calibrated: {new Date(calibration.lastCalibrated).toLocaleTimeString()}
                    </div>
                </div>
            </div>
        )}
      </header>

      {/* Main Lab Interface */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* LEFT SIDEBAR: Control Panel */}
        <aside className="w-72 bg-slate-950/50 border-r border-slate-800 flex flex-col overflow-y-auto">
            
            {/* 1. Experiment Config */}
            <div className="p-4 border-b border-slate-800">
                <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <Settings size={14} /> System Config
                </h2>
                
                {/* Molecule Selector */}
                <div className="mb-5">
                    <label className="text-[10px] text-slate-400 font-bold uppercase mb-1.5 block">Target System</label>
                    <div className="relative">
                        <select 
                            value={activeMoleculeId}
                            onChange={(e) => setActiveMoleculeId(e.target.value as MoleculeType)}
                            className="w-full bg-slate-800 text-slate-200 text-xs rounded-lg border border-slate-700 px-3 py-2.5 appearance-none focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                        >
                            {Object.values(MOLECULES).map(mol => (
                                <option key={mol.id} value={mol.id}>{mol.name} ({mol.formula})</option>
                            ))}
                        </select>
                        <Atom className="absolute right-3 top-2.5 text-slate-500 pointer-events-none" size={14} />
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1">{activeMolecule.description}</div>
                </div>

                {/* Noise Model Selector */}
                <div className="mb-5">
                    <label className="text-[10px] text-slate-400 font-bold uppercase mb-1.5 block">Noise Model</label>
                    <div className="relative">
                        <select 
                            value={noiseModel}
                            onChange={(e) => setNoiseModel(e.target.value as NoiseModelType)}
                            className="w-full bg-slate-800 text-slate-200 text-xs rounded-lg border border-slate-700 px-3 py-2.5 appearance-none focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                        >
                            {Object.values(NOISE_MODELS).map(model => (
                                <option key={model.id} value={model.id}>{model.name}</option>
                            ))}
                        </select>
                        <Waves className="absolute right-3 top-2.5 text-slate-500 pointer-events-none" size={14} />
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1">{NOISE_MODELS[noiseModel].desc}</div>
                </div>

                {/* Shots Control */}
                <div className="mb-5">
                    <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Shot Budget</span>
                        <span className="font-mono text-indigo-400 bg-indigo-950/30 px-1.5 rounded">{shots.toLocaleString()}</span>
                    </div>
                    <input 
                        type="range" min="1000" max="50000" step="1000"
                        value={shots}
                        onChange={(e) => setShots(parseInt(e.target.value))}
                        className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400"
                    />
                </div>

                {/* Noise Control */}
                <div className="mb-6">
                    <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Noise (Gamma)</span>
                        <span className="font-mono text-cyan-400 bg-cyan-950/30 px-1.5 rounded">{noiseLevel.toFixed(3)}</span>
                    </div>
                    <input 
                        type="range" min="0.005" max="0.15" step="0.005"
                        value={noiseLevel}
                        onChange={(e) => setNoiseLevel(parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500 hover:accent-cyan-400"
                    />
                </div>

                {/* Action Button */}
                <button
                    onClick={handleRunExperiment}
                    disabled={loading || activeStrategies.length === 0}
                    className={`w-full py-2.5 rounded-lg font-bold text-xs uppercase tracking-wide flex items-center justify-center gap-2 transition-all shadow-lg
                        ${loading 
                        ? 'bg-slate-800 text-slate-500 cursor-wait' 
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20 hover:shadow-indigo-600/40 border border-indigo-500'}`}
                >
                    {loading ? (
                        <>
                            <div className="w-3 h-3 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                            Processing...
                        </>
                    ) : (
                        <>
                            <Play size={14} fill="currentColor" />
                            Run Simulation
                        </>
                    )}
                </button>
            </div>

            {/* 2. Strategies */}
            <div className="p-4 flex-1">
                <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <Activity size={14} /> Active Mitigation
                </h2>
                <div className="space-y-2">
                    {Object.values(STRATEGIES).map((strat) => {
                        const isActive = activeStrategies.includes(strat.id);
                        return (
                            <button
                                key={strat.id}
                                onClick={() => toggleStrategy(strat.id)}
                                className={`w-full p-2.5 rounded-lg border text-left transition-all duration-200 group flex items-start gap-3
                                ${isActive ? 'bg-slate-800/80 border-slate-700 shadow-sm' : 'bg-transparent border-slate-800 hover:bg-slate-800/50 hover:border-slate-700'}
                                `}
                                style={{ borderColor: isActive ? strat.color : '' }}
                            >
                                <div className={`mt-0.5 p-1 rounded ${isActive ? 'bg-slate-950' : 'bg-slate-900'}`} style={{ color: strat.color }}>
                                    {getIconForStrategy(strat.type)}
                                </div>
                                <div>
                                    <div className="font-semibold text-xs text-slate-200 group-hover:text-white">{strat.name}</div>
                                    <div className="text-[10px] text-slate-500 leading-tight mt-0.5">{strat.description}</div>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </div>
        </aside>

        {/* CENTER: Visualization Area */}
        <main className="flex-1 overflow-y-auto p-6 relative">
            
            {/* References Modal */}
            {showReferences && (
                <div className="absolute inset-0 z-40 bg-slate-900/90 backdrop-blur-sm p-8 flex flex-col items-center justify-center">
                    <div className="bg-[#0f172a] border border-slate-700 rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
                        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950 sticky top-0">
                            <h2 className="text-lg font-bold text-slate-200">Literature & References</h2>
                            <button onClick={() => setShowReferences(false)} className="text-slate-500 hover:text-white">
                                <XCircle size={24} />
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            {LITERATURE.map(paper => (
                                <div key={paper.id} className="p-4 bg-slate-900 rounded-lg border border-slate-800 hover:border-indigo-900 transition-colors">
                                    <div className="flex justify-between items-start mb-1">
                                        <h3 className="font-bold text-slate-200 text-sm">{paper.title}</h3>
                                        <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400 border border-slate-700 whitespace-nowrap">{paper.category}</span>
                                    </div>
                                    <p className="text-xs text-slate-400 italic mb-2">{paper.authors} — {paper.journal} ({paper.year})</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            <div className="max-w-6xl mx-auto space-y-6">
                
                {/* Results Chart */}
                <section>
                   <div className="flex justify-end mb-2">
                     <button
                        onClick={handleExportData}
                        disabled={Object.keys(results).length === 0}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors
                        ${Object.keys(results).length > 0 ? 'bg-indigo-600 text-white hover:bg-indigo-500' : 'bg-slate-800 text-slate-500 cursor-not-allowed'}`}
                     >
                        <Download size={14} /> Export Results (JSON)
                     </button>
                   </div>
                   <ResultsChart 
                      results={results} 
                      activeStrategies={activeStrategies} 
                      loading={loading}
                      activeMoleculeName={activeMolecule.formula}
                      activeNoiseModelName={NOISE_MODELS[noiseModel].name}
                   />
                </section>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    
                    {/* Scientific Disclaimer Panel */}
                    <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-5 text-xs h-full">
                        <div className="flex items-center gap-2 mb-3 text-slate-400 uppercase tracking-widest font-bold border-b border-slate-800/50 pb-2">
                            <AlertCircle size={14} /> Experimental Context
                        </div>
                        <ul className="list-disc list-outside ml-4 space-y-2 text-slate-500 leading-relaxed">
                            <li>
                                <strong>System:</strong> {activeMolecule.name} on {activeMolecule.qubits} Qubits.
                            </li>
                            <li>
                                <strong>Sampling Noise:</strong> Errors include statistical noise {'(\u03C3 \u221D 1/\u221AN'}<sub>valid</sub>{')'}. For {shots.toLocaleString()} shots, the floor is approx {(1000/Math.sqrt(shots)).toFixed(1)} mHa.
                            </li>
                            <li>
                                <strong>RL Policy:</strong> The PPO agent (stochastic) explores strategy space. It may not strictly dominate Hybrid due to exploration noise and switching costs.
                            </li>
                        </ul>
                    </div>

                    {/* Circuit Blueprint / Info */}
                    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md flex flex-col">
                        <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-slate-950">
                            <h3 className="font-semibold text-slate-300 text-xs uppercase tracking-wide flex items-center gap-2">
                                <Cpu size={14} /> {activeMolecule.formula} Ansatz
                            </h3>
                            <div className="flex gap-2">
                                <button onClick={() => loadConcept("Dynamical Decoupling")} className="text-[10px] hover:text-white text-slate-500 transition-colors">? DD</button>
                                <button onClick={() => loadConcept("Symmetry Verification")} className="text-[10px] hover:text-white text-slate-500 transition-colors">? Sym</button>
                            </div>
                        </div>
                        <div className="p-4 bg-[#0f172a] flex-1 flex items-center justify-center opacity-90 grayscale hover:grayscale-0 transition-all duration-500">
                             <CircuitDiagram circuit={activeCircuit} readOnly={true} onAddGate={()=>{}} onRemoveGate={()=>{}} />
                        </div>
                    </div>
                </div>

                {/* AI Analysis Box */}
                {activeStrategies.includes('SYNERGISTIC') && results['SYNERGISTIC'] && (
                    <div className="bg-gradient-to-r from-slate-900 to-slate-900/50 border-l-4 border-l-emerald-500 border-y border-r border-slate-800 rounded-r-xl p-5 shadow-lg">
                        <h3 className="text-emerald-400 font-semibold mb-2 flex items-center gap-2 text-sm uppercase tracking-wide">
                        <Database size={16} />
                        Automated Lab Note
                        </h3>
                        <p className="text-sm text-slate-300 leading-relaxed font-light">
                        {results['SYNERGISTIC'].analysis}
                        </p>
                    </div>
                )}
                
                {/* Dynamic Explanation Toast */}
                {explanation && (
                    <div className="fixed bottom-6 right-6 max-w-sm bg-slate-800 border border-slate-700 p-4 rounded-xl shadow-2xl animate-in slide-in-from-bottom-5 z-50">
                        <div className="flex justify-between items-start mb-2">
                            <h4 className="text-xs font-bold text-indigo-400 uppercase">Knowledge Base</h4>
                            <button onClick={() => setExplanation(null)} className="text-slate-500 hover:text-white"><XCircle size={14}/></button>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">{explanation}</p>
                    </div>
                )}
            </div>
        </main>
      </div>
    </div>
  );
};

export default App;